# Tecnologia em Movimento

Temas: Inovação, Tecnologia
Files & media: Leonardo_Phoenix_10_crie_uma_imagem_que_represente_uma_mulher_2.jpg, https://cdn.discordapp.com/attachments/989274728155992124/1123468239029157918/felipe-aguiar.exe_create_knight_character_as_podcaster_medieval_3946503c-ae13-4517-9dff-550bf49efd24.png, felipe-aguiar.exe_a_cartoon_cellshadding_podcast_studio_like_ul_5d61ba7b-8d78-404c-8731-aa4cb177fb37.png, original_images.zip, https://app.leonardo.ai/image-generation
Files & media (1): Podcast.mp4
db_espisodes: PODCAST EP01 - Hello World (https://www.notion.so/PODCAST-EP01-Hello-World-175df8815c738181a1d6c96bb5e57fb7?pvs=21), Episódio 1_ IA e o novo mercado de trabalho (https://www.notion.so/Epis-dio-1_-IA-e-o-novo-mercado-de-trabalho-175df8815c7380c08196dd9152e50463?pvs=21)